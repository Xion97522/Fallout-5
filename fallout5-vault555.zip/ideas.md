# Fallout 5: Vault 555 — Design Brainstorm

## Context
This is a fan-made 3D first-person shooter game built with Three.js. The game already exists as a complete HTML file with all game logic. Our job is to wrap it in a polished mobile web app shell that:
1. Hosts the game in an iframe / direct embed
2. Serves all game assets (3D models, textures, audio, JS libraries) correctly
3. Fixes the .mtl texture bug (.png → .webp)

Since the game itself is a complete self-contained HTML page, the "app" is essentially a static file server that delivers the game assets at the right paths.

## Approach
The game's index.html references assets at root-relative paths like:
- `/monofonto.woff`
- `/theme.mp3`
- `/standby.mp4`
- `/menu_bg.gif`
- `/skybox.webp`
- `/js/three.min.js`
- `/bloatfly/Bloatfly/Bloatfly.obj`
- `/textures/tiles/tile_albedo.webp`
- etc.

The simplest and most correct approach is to:
1. Copy all game assets into `client/public/` (they are small enough or we use the static asset server)
2. Serve `index.html` as the main page directly
3. Since this is a React app, we'll use an iframe approach or replace the React app entirely with the game

**Decision: Replace the React app's index.html with the game directly, serving assets from public/**

<response>
<text>
## Approach A: Direct Game Embed (Chosen)
- Design Movement: Retro-futurist CRT terminal aesthetic
- The game IS the app — serve the fixed game HTML directly
- All assets served from the correct paths
- Mobile-optimized viewport meta tags
- No React overhead, pure performance
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Approach B: React Shell with iframe
- React landing page with Fallout-themed UI wrapping the game in an iframe
- Adds unnecessary complexity
</text>
<probability>0.06</probability>
</response>

<response>
<text>
## Approach C: Vite static with game as entry
- Use Vite to serve the game HTML as a static file
- React app redirects to /game.html
</text>
<probability>0.07</probability>
</response>

## Chosen: Approach A — Direct Game Embed
The game HTML will be the main page. We'll configure Vite to serve it correctly with all assets at the right paths.
