/**
 * Fallout 5: Vault 555 — Fan Game
 * Design: Retro-futurist CRT terminal aesthetic
 * This page is a fullscreen iframe wrapper for the Three.js game
 */
export default function Home() {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        background: "#000",
        margin: 0,
        padding: 0,
      }}
    >
      <iframe
        src="/game.html"
        title="Fallout 5: Vault 555"
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          border: "none",
          display: "block",
        }}
        allow="autoplay; fullscreen; pointer-lock; vibrate"
        allowFullScreen
      />
    </div>
  );
}
